export declare const prod: {
    mysql: {
        type: string;
        host: string;
        port: number;
        username: string;
        password: string;
        database: string;
        entities: any[];
        synchronize: boolean;
        autoLoadEntities: boolean;
    };
    mail: {
        host: string;
        port: number;
        ignoreTLS: boolean;
        secure: boolean;
        auth: {
            user: string;
            pass: string;
        };
        from: string;
    };
};
export declare const dev: {
    mysql: {
        type: string;
        host: string;
        port: number;
        username: string;
        password: string;
        database: string;
        entities: any[];
        synchronize: boolean;
        autoLoadEntities: boolean;
    };
    mail: {
        host: string;
        port: number;
        ignoreTLS: boolean;
        secure: boolean;
        auth: {
            user: string;
            pass: string;
        };
        from: string;
    };
};
declare const _default: () => {
    mysql: {
        type: string;
        host: string;
        port: number;
        username: string;
        password: string;
        database: string;
        entities: any[];
        synchronize: boolean;
        autoLoadEntities: boolean;
    };
    mail: {
        host: string;
        port: number;
        ignoreTLS: boolean;
        secure: boolean;
        auth: {
            user: string;
            pass: string;
        };
        from: string;
    };
};
export default _default;
