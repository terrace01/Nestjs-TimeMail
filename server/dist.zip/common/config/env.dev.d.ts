export declare const db: {
    host: string;
    port: number;
    username: string;
    password: string;
    database: string;
};
export declare const mail: {
    host: string;
    port: number;
    ignoreTLS: boolean;
    secure: boolean;
    auth: {
        user: string;
        pass: string;
    };
    from: string;
};
