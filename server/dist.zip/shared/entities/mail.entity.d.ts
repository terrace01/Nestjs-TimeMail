export declare class Mail {
    id: number;
    name: string;
    email: string;
    content: string;
    time_start: number;
    time_end: number;
    type: number;
    is_public: number;
}
