export declare class CreateMailDto {
    id?: number;
    name: string;
    email: string;
    content: string;
    time_start: Date;
    S: any;
    time_end: Date;
    type: number;
}
