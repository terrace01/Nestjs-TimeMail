export declare function timetrans(date: any): string;
