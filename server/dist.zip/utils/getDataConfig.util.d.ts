export declare const dev: {
    db: {
        host: string;
        port: number;
        username: string;
        password: string;
        database: string;
    };
    mail: {
        host: string;
        port: number;
        ignoreTLS: boolean;
        secure: boolean;
        auth: {
            user: string;
            pass: string;
        };
        from: string;
    };
};
export declare const prod: {
    db: {
        host: string;
        port: number;
        username: string;
        password: string;
        database: string;
    };
    mail: {
        host: string;
        port: number;
        ignoreTLS: boolean;
        secure: boolean;
        auth: {
            user: string;
            pass: string;
        };
        from: string;
    };
};
export declare const env: {
    host: string;
    port: number;
    database: string;
    username: string;
    password: string;
};
