"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.env = exports.prod = exports.dev = void 0;
exports.dev = {
    db: {
        "host": "127.0.0.1",
        "port": 3306,
        "username": "root",
        "password": "123456",
        "database": "timepost",
    },
    mail: {
        "host": "smtp.163.com",
        "port": 25,
        "ignoreTLS": true,
        "secure": false,
        "auth": {
            "user": "raseluxun@163.com",
            "pass": "VKUOWCQYLBCURDQQ"
        },
        "from": '"鲁迅" <raseluxun@163.com>',
    }
};
exports.prod = {
    db: {
        "host": "127.0.0.1",
        "port": 3306,
        "username": "root",
        "password": "123456",
        "database": "timepost",
    },
    mail: {
        "host": "smtp.163.com",
        "port": 25,
        "ignoreTLS": true,
        "secure": false,
        "auth": {
            "user": "raseluxun@163.com",
            "pass": "VKUOWCQYLBCURDQQ"
        },
        "from": '"鲁迅" <raseluxun@163.com>',
    }
};
exports.env = {
    host: process.env.DB_HOST ? exports.prod.db.host : exports.dev.db.host,
    port: process.env.DB_PORT ? Number(exports.prod.db.port) : exports.dev.db.port,
    database: process.env.DB_DATABASE ? exports.prod.db.database : exports.dev.db.database,
    username: process.env.DB_USERNAME ? exports.prod.db.username : exports.dev.db.username,
    password: process.env.DB_PASSWORD ? exports.prod.db.password : exports.dev.db.password,
};
//# sourceMappingURL=getDataConfig.util.js.map