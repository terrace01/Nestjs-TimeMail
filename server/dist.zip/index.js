"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.environment = void 0;
const dev = require("../src/common/config/env.dev");
const prop = require("../src/common/config/env.dev");
const envconfigs = {
    development: dev,
    production: prop,
};
const environment = envconfigs[process.env.NODE_ENV || 'development'];
exports.environment = environment;
//# sourceMappingURL=index.js.map