"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MailService = void 0;
const common_1 = require("@nestjs/common");
const mail_entity_1 = require("../../shared/entities/mail.entity");
const typeorm_1 = require("typeorm");
const typeorm_2 = require("@nestjs/typeorm");
const schedule_1 = require("@nestjs/schedule");
const cron_1 = require("cron");
const mailer_1 = require("@nestjs-modules/mailer");
const time_1 = require("../../utils/time");
let MailService = class MailService {
    constructor(MailRepository, schedulerRegistry, mailerService) {
        this.MailRepository = MailRepository;
        this.schedulerRegistry = schedulerRegistry;
        this.mailerService = mailerService;
    }
    async getAllBySkip(skip) {
        const [result, total] = await this.MailRepository.findAndCount({
            where: { is_public: 1 }, order: { time_start: "DESC" },
            take: 2,
            skip: skip
        });
        return { result, total };
    }
    async getAll() {
        return await this.MailRepository.find({ order: { time_start: "DESC" },
        });
    }
    createMail(dto) {
        const { email, content, time_end } = dto;
        const date = new Date((0, time_1.timetrans)(time_end));
        const job = new cron_1.CronJob(date, () => {
            this.mailerService.sendMail({
                to: email,
                from: "raseluxun@163.com",
                subject: "hey，一封来自过去的信 - 时光邮局",
                template: '/mail',
                context: {
                    content,
                    date,
                    sign: '系统邮件,回复无效。'
                }
            })
                .then(() => {
                common_1.Logger.log("邮件id:" + dto.id + " 状态:发送成功");
                this.MailRepository.update(dto.id, { type: 1 });
            })
                .catch((err) => {
                common_1.Logger.log("邮件id:" + dto.id + " 状态:发送失败" + " 原因" + err);
                this.MailRepository.update(dto.id, { type: 2 });
            });
        });
        this.schedulerRegistry.addCronJob(Math.floor(Math.random() * 10) + '', job);
        job.start();
        return this.MailRepository.save(dto);
    }
    deleteMailById(id) {
        return this.MailRepository.delete(id);
    }
    updateMailByMailId(dto) {
        return this.MailRepository.save(dto);
    }
    getMailByMailId(id) {
        return this.MailRepository.findByIds(id);
    }
    async init() {
        const res = await this.MailRepository.find({ type: 0 });
        for (const i in res) {
            this.createMail(res[i]);
        }
    }
};
MailService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_2.InjectRepository)(mail_entity_1.Mail)),
    __metadata("design:paramtypes", [typeorm_1.Repository,
        schedule_1.SchedulerRegistry,
        mailer_1.MailerService])
], MailService);
exports.MailService = MailService;
//# sourceMappingURL=mail.service.js.map