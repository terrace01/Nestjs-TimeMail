import { Mail } from "../../shared/entities/mail.entity";
import { Repository } from "typeorm";
import { SchedulerRegistry } from '@nestjs/schedule';
import { MailerService } from '@nestjs-modules/mailer';
export declare class MailService {
    private MailRepository;
    private schedulerRegistry;
    private mailerService;
    constructor(MailRepository: Repository<Mail>, schedulerRegistry: SchedulerRegistry, mailerService: MailerService);
    getAllBySkip(skip: any): Promise<{
        result: Mail[];
        total: number;
    }>;
    getAll(): Promise<Mail[]>;
    createMail(dto: any): Promise<any>;
    deleteMailById(id: any): Promise<import("typeorm").DeleteResult>;
    updateMailByMailId(dto: any): Promise<any>;
    getMailByMailId(id: any): Promise<Mail[]>;
    init(): Promise<void>;
}
