export declare class MailModule {
}
