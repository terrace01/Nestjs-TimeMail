import { MailService } from "./mail.service";
import { CreateMailDto } from '../../shared/dto/create-mail-dto';
export declare class MailController {
    private mailServer;
    constructor(mailServer: MailService);
    getAlL(): Promise<import("../../shared/entities/mail.entity").Mail[]>;
    getAllBySkip(skip: number): Promise<{
        result: import("../../shared/entities/mail.entity").Mail[];
        total: number;
    }>;
    createMail(dto: CreateMailDto): Promise<any>;
    updateMailByMailId(dto: CreateMailDto): Promise<any>;
    deleteMailById(id: number): Promise<import("../../shared/entities/mail.entity").Mail[]>;
    getMailByMailId(id: number): Promise<import("../../shared/entities/mail.entity").Mail[]>;
}
