declare const environment: any;
export { environment };
