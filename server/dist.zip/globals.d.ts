declare const globals: {
    API_VERSION: string;
};
export default globals;
