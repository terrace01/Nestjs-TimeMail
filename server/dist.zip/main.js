"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@nestjs/core");
const app_module_1 = require("./app.module");
const globals_1 = require("./globals");
const http_execption_filter_1 = require("./common/filters/http-execption.filter");
const transform_interceptor_1 = require("./common/interceptor/transform.interceptor");
const swagger_1 = require("@nestjs/swagger");
const mail_service_1 = require("./modules/mail/mail.service");
async function bootstrap() {
    const app = await core_1.NestFactory.create(app_module_1.AppModule);
    app.useGlobalInterceptors(new transform_interceptor_1.TransformInterceptor());
    app.useGlobalFilters(new http_execption_filter_1.HttpExecptionFilter());
    app.setGlobalPrefix("api/v" + globals_1.default.API_VERSION);
    app.enableCors();
    const options = new swagger_1.DocumentBuilder()
        .setTitle('TimePost-serve')
        .setDescription('接口文档')
        .setVersion('1.0')
        .build();
    const document = swagger_1.SwaggerModule.createDocument(app, options);
    swagger_1.SwaggerModule.setup('doc', app, document);
    await app.listen(8080);
    const mailService = app.get(mail_service_1.MailService);
}
bootstrap();
//# sourceMappingURL=main.js.map