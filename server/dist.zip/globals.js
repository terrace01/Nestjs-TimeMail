"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const globals = {
    API_VERSION: "1",
};
exports.default = globals;
//# sourceMappingURL=globals.js.map